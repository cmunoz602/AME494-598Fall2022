# esp32-camera

## Requirements

https://github.com/Xinyuan-LilyGO/CH9102_Mac_Driver

https://github.com/Xinyuan-LilyGO/CH9102_Driver
